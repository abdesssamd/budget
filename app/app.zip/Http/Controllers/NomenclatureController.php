<?php

namespace App\Http\Controllers;

class NomenclatureController extends Controller
{
    public function index()
    {
        return 'Page Nomenclature';
    }
}
