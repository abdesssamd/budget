@extends('layouts.app')

@section('content')
<h1>Test Livewire</h1>
<livewire:test-component />
@endsection
