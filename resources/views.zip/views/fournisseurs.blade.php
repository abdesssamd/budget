@extends('layouts.app')

@section('content')
    <livewire:fournisseurs-crud />
@endsection
