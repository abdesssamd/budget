@extends('layouts.app')

@section('content')
    <livewire:produits-crud />
@endsection
