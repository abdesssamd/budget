@extends('layouts.app')

{{-- Titre de la page pour le navigateur --}}
@section('title', 'Tableau de bord')

{{-- En-tête H1 géré par AdminLTE --}}
@section('header')
    <i class="fas fa-cogs mr-2"></i>Tableau de bord
@endsection

