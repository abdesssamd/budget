<?php

return [
    'financial_control' => 'الرقابة المالية',
    'status' => 'حالة التأشيرة',
    'sent_date' => 'تاريخ الإرسال',
    'number' => 'رقم التأشيرة',
    'date' => 'تاريخ التأشيرة',
    'scan' => 'مسح الوثيقة',
    'view_scan' => 'عرض الملف',
    'observations' => 'ملاحظات',
    'save' => 'حفظ التأشيرة',
    'sent_on' => 'أرسل في',
    'not_sent' => 'غير مرسل',
];