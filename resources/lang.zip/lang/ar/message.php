<?php

return [
    'insufficient_balance' => 'المبلغ أكبر من الرصيد المتاح',
    'repartition_success' => 'تم التوزيع بنجاح !',
    'repartition_cancelled' => 'تم إلغاء التوزيع، المبلغ عاد للميزانية الإجمالية.',
    'visa_saved' => 'تم تحديث معلومات التأشيرة.',
    'confirm_cancel_repartition' => 'إلغاء هذا التوزيع؟ سيعود المال إلى الميزانية الإجمالية.',
];