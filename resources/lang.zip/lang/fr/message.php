<?php

return [
    'insufficient_balance' => 'Montant supérieur au reste disponible',
    'repartition_success' => 'Répartition effectuée avec succès !',
    'repartition_cancelled' => 'Répartition annulée, montant restitué.',
    'visa_saved' => 'Informations Visa mises à jour.',
    'confirm_cancel_repartition' => 'Annuler cette répartition ? L\'argent retournera au budget global.',
];