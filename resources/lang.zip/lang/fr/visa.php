<?php

return [
    'financial_control' => 'Contrôle Financier',
    'status' => 'État CF',
    'sent_date' => 'Date d\'envoi',
    'number' => 'N° Visa',
    'date' => 'Date du Visa',
    'scan' => 'Scan du document',
    'view_scan' => 'Voir le fichier',
    'observations' => 'Observations',
    'save' => 'Enregistrer le Visa',
    'sent_on' => 'Envoyé le',
    'not_sent' => 'Non envoyé',
];